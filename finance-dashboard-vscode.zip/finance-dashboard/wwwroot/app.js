const API = "/api";
const currency = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
const dateInput = document.querySelector("#date");
dateInput.value = new Date().toISOString().slice(0, 10);

const form = document.querySelector("#transaction-form");
const message = document.querySelector("#form-message");
const list = document.querySelector("#transaction-list");

async function loadDashboard() {
  try {
    const [summaryResponse, transactionsResponse] = await Promise.all([
      fetch(`${API}/summary`),
      fetch(`${API}/transactions`)
    ]);
    if (!summaryResponse.ok || !transactionsResponse.ok) throw new Error("Não foi possível carregar os dados.");

    const summary = await summaryResponse.json();
    const transactions = await transactionsResponse.json();

    document.querySelector("#balance").textContent = currency.format(summary.balance);
    document.querySelector("#balance").classList.toggle("negative", summary.balance < 0);
    document.querySelector("#balance").classList.toggle("positive", summary.balance >= 0);
    document.querySelector("#income").textContent = currency.format(summary.income);
    document.querySelector("#expenses").textContent = currency.format(summary.expenses);
    document.querySelector("#transaction-count").textContent =
      `${summary.count} ${summary.count === 1 ? "registro" : "registros"}`;

    renderTransactions(transactions);
  } catch (error) {
    list.innerHTML = `<tr><td colspan="4" class="empty">${escapeHtml(error.message)}</td></tr>`;
  }
}

function renderTransactions(transactions) {
  if (!transactions.length) {
    list.innerHTML = '<tr><td colspan="4" class="empty">Nenhum lançamento por enquanto. Adicione o primeiro ao lado.</td></tr>';
    return;
  }

  list.innerHTML = transactions.map(item => {
    const isIncome = item.type === "income";
    const date = new Date(`${item.date.slice(0, 10)}T12:00:00`).toLocaleDateString("pt-BR");
    const sign = isIncome ? "+" : "−";
    return `
      <tr>
        <td>${escapeHtml(item.description)}<br><small style="color:#929bad;font-weight:400">${escapeHtml(item.category)}</small></td>
        <td>${date}</td>
        <td class="${isIncome ? "amount-income" : "amount-expense"}">${sign} ${currency.format(item.amount)}</td>
        <td><button class="delete-button" data-id="${item.id}" aria-label="Excluir ${escapeHtml(item.description)}">Excluir</button></td>
      </tr>`;
  }).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  message.textContent = "";
  const button = form.querySelector("button[type='submit']");
  button.disabled = true;

  const data = new FormData(form);
  const payload = {
    description: data.get("description"),
    amount: Number(data.get("amount")),
    type: data.get("type"),
    category: data.get("category"),
    date: data.get("date")
  };

  try {
    const response = await fetch(`${API}/transactions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.message || "Erro ao salvar lançamento.");

    form.reset();
    dateInput.value = new Date().toISOString().slice(0, 10);
    message.style.color = "#15965b";
    message.textContent = "Lançamento adicionado com sucesso!";
    await loadDashboard();
  } catch (error) {
    message.style.color = "#df5864";
    message.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

list.addEventListener("click", async event => {
  const button = event.target.closest(".delete-button");
  if (!button) return;
  if (!confirm("Deseja realmente excluir este lançamento?")) return;

  try {
    const response = await fetch(`${API}/transactions/${button.dataset.id}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Não foi possível excluir o lançamento.");
    await loadDashboard();
  } catch (error) {
    alert(error.message);
  }
});

loadDashboard();
