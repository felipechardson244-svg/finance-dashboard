using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

var dataDirectory = Path.Combine(app.Environment.ContentRootPath, "App_Data");
Directory.CreateDirectory(dataDirectory);
var dataFile = Path.Combine(dataDirectory, "transactions.json");
var jsonOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true, WriteIndented = true };

var transactions = LoadTransactions();

List<Transaction> LoadTransactions()
{
    if (!File.Exists(dataFile)) return new List<Transaction>();
    try
    {
        return JsonSerializer.Deserialize<List<Transaction>>(File.ReadAllText(dataFile), jsonOptions)
               ?? new List<Transaction>();
    }
    catch
    {
        return new List<Transaction>();
    }
}

void SaveTransactions()
{
    File.WriteAllText(dataFile, JsonSerializer.Serialize(transactions, jsonOptions));
}

app.MapGet("/api/transactions", () =>
    transactions.OrderByDescending(t => t.Date).ThenByDescending(t => t.Id));

app.MapGet("/api/summary", () =>
{
    var income = transactions.Where(t => t.Type == "income").Sum(t => t.Amount);
    var expenses = transactions.Where(t => t.Type == "expense").Sum(t => t.Amount);
    return Results.Ok(new { income, expenses, balance = income - expenses, count = transactions.Count });
});

app.MapPost("/api/transactions", (TransactionInput input) =>
{
    if (string.IsNullOrWhiteSpace(input.Description))
        return Results.BadRequest(new { message = "Informe uma descrição." });

    if (input.Amount <= 0)
        return Results.BadRequest(new { message = "O valor deve ser maior que zero." });

    if (input.Type is not ("income" or "expense"))
        return Results.BadRequest(new { message = "Tipo inválido." });

    var transaction = new Transaction
    {
        Id = Guid.NewGuid(),
        Description = input.Description.Trim(),
        Amount = decimal.Round(input.Amount, 2),
        Type = input.Type,
        Category = string.IsNullOrWhiteSpace(input.Category) ? "Outros" : input.Category.Trim(),
        Date = input.Date == default ? DateTime.Today : input.Date.Date
    };

    transactions.Add(transaction);
    SaveTransactions();
    return Results.Created($"/api/transactions/{transaction.Id}", transaction);
});

app.MapDelete("/api/transactions/{id:guid}", (Guid id) =>
{
    var transaction = transactions.FirstOrDefault(t => t.Id == id);
    if (transaction is null) return Results.NotFound(new { message = "Lançamento não encontrado." });

    transactions.Remove(transaction);
    SaveTransactions();
    return Results.NoContent();
});

app.Run();

public class Transaction
{
    public Guid Id { get; set; }
    public string Description { get; set; } = "";
    public decimal Amount { get; set; }
    public string Type { get; set; } = "expense";
    public string Category { get; set; } = "Outros";
    public DateTime Date { get; set; }
}

public record TransactionInput(
    string Description,
    decimal Amount,
    string Type,
    string? Category,
    DateTime Date
);
