# Finance Dashboard

Dashboard financeiro pessoal desenvolvido com C#, ASP.NET Core, HTML, CSS e JavaScript.

## Requisitos
- .NET 8 SDK ou superior
- Visual Studio Code

## Como executar
1. Extraia a pasta do projeto.
2. Abra a pasta `finance-dashboard` no VS Code.
3. Abra o terminal integrado (`Terminal > New Terminal`).
4. Execute:

```bash
dotnet restore
dotnet run
```

5. O terminal mostrará o endereço local. Abra no navegador o endereço indicado (normalmente `http://localhost:5000` ou `https://localhost:7000`).

## Funcionalidades
- Cadastro de receitas e despesas.
- Exclusão de lançamentos.
- Resumo automático de receitas, despesas e saldo.
- Histórico ordenado por data.
- Persistência local em `App_Data/transactions.json`.

## Estrutura
- `Program.cs`: API e regras do backend em C#.
- `wwwroot/index.html`: estrutura da interface.
- `wwwroot/style.css`: estilos.
- `wwwroot/app.js`: comunicação com a API e atualização da tela.
- `App_Data/transactions.json`: dados persistidos (criado automaticamente).

> Projeto de estudo. Para uso real com dados financeiros, adicione autenticação, banco de dados, backups e proteção adequada dos dados.
